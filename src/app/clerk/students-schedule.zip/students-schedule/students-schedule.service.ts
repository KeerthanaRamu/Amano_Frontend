import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { Calendar } from "./students-schedule.model";
import { Observable } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { environment } from '../../../environments/environment'
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class StudentScheduleService {

  private readonly API_URL = "assets/data/calendar.json";
  httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
    }),
  };
  dataChange: BehaviorSubject<Calendar[]> = new BehaviorSubject<Calendar[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  constructor(private http: HttpClient) {}
  get data(): Calendar[] {
    return this.dataChange.value;
  }
  getDialogData() {
    return this.dialogData;
  }
  getAllCalendars(): Observable<Calendar[]> {
    return this.http
      .get<Calendar[]>(this.API_URL)
      .pipe(catchError(this.errorHandler));
  }


  deleteCalendar(calendar: Calendar): void {
    this.dialogData = calendar;
  }
  errorHandler(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

  getScheduleList(){
    return this.http
    .get<any>(`${environment.apiUrl}/webRoutes/getScheduleList`)
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  setScheduleDetails(calendarData,timeSlot,viewAssign_selected,authToken,client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/setScheduleDetails`,{calendarData,timeSlot,viewAssign_selected,authToken,client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getScheduleDetailsForStudent(statusid,client,authToken){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getScheduleDetailsForStudent`,{statusid,client,authToken})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  updateScheduleDetails(calendarData,viewAssign_selected,authToken,client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/updateScheduleDetails`,{calendarData,viewAssign_selected,authToken,client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  deleteScheduleDetails(calendarData,authToken,client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/deleteScheduleDetails`,{calendarData,authToken,client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getTimeDetails(client){
    return this.http
      .post<any>(`${environment.apiUrl}/webRoutes/getTimeDetails`,{client})
      .pipe(
        map((res) => {
          return res;
        })
      );
  }
  
  getSelectedScheduleInfoStudent(enrollData,client){
    return this.http
      .post<any>(`${environment.apiUrl}/webRoutes/getSelectedScheduleInfoStudent`,{enrollData,client})
      .pipe(
        map((res) => {
          return res;
        })
      );
  }

  getNRICNumberForStudentSchedule(clientid){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getNRICNumberForStudentSchedule`,{clientid})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getPassportNumberForStudentSchedule(clientid){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getPassportNumberForStudentSchedule`,{clientid})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getEnrollmentNumberForSchedule(studentId,clientid){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getEnrollmentNumberForSchedule`,{studentId,clientid})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getEnrollDetailsForSchedule(studentId,clientid){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getEnrollDetailsForSchedule`,{studentId,clientid})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  setStudentScheduleInfo(finalArray,enrollData,clientid){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/setStudentScheduleInfo`,{finalArray,enrollData,clientid})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

}
