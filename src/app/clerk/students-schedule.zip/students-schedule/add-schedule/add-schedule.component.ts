import { Component, ViewChild, OnInit } from '@angular/core';
import {
  CalendarOptions,
  DateSelectArg,
  EventClickArg,
  EventApi,
} from '@fullcalendar/angular';
import { Observable,map, startWith,debounceTime,switchMap,of } from 'rxjs';
import {  FormBuilder, FormGroup, Validators,FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { EventInput } from '@fullcalendar/angular';
import { MatDialog } from '@angular/material/dialog';
import { StudentScheduleService } from '../students-schedule.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { FormDialogComponent } from '../dialogs/form-dialog/form-dialog.component';
import { Calendar } from '../students-schedule.model';
import { UnsubscribeOnDestroyAdapter } from '../../../shared/UnsubscribeOnDestroyAdapter';
import { formatDate } from '@angular/common';

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null  /* valid option selected */
  }
}

@Component({
  selector: 'app-add-schedule',
  templateUrl: './add-schedule.component.html',
  styleUrls: ['./add-schedule.component.scss']
})
export class AddScheduleComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  @ViewChild('calendar', { static: false })
  calendar: Calendar | null;
  public addCusForm: FormGroup;
  scheduleList;

  dialogTitle: string;
  filterOptions = 'All';
  calendarData=[];
  filterItems =[]

  calendarEvents: EventInput[];
  tempEvents: EventInput[];

  nricNumberData:any;
  passportNumberData:any;


  nric_number= new FormControl('', { validators: [autocompleteObjectValidator()] });
  passport_number= new FormControl('', { validators: [autocompleteObjectValidator()] });

  nricNumberList: Observable<string[]>;
  passportNumberList: Observable<string[]>;

  public validation_msgs = {
    'nric_number': [
      { type: 'invalidAutocompleteObject', message: 'NRIC Number not recognized. Click one of the options.' }
    ],
    'passport_number': [
      { type: 'invalidAutocompleteObject', message: 'Passport Number not recognized. Click one of the options.' }
    ],
  }
  enrollDetails: any;

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    public calendarService: StudentScheduleService,
    private snackBar: MatSnackBar
  ) {
    super();
    this.dialogTitle = 'Add New Event';
    this.calendar = new Calendar({});
    this.addCusForm = this.createCalendarForm(this.calendar);
    this.getScheduleList();

  }

  public ngOnInit(): void {
    
    
    this.getNRICNumberForStudentSchedule();
    this.getPassportNumberForStudentSchedule();
    
  }



  getNRICNumberForStudentSchedule(){
    this.calendarService.getNRICNumberForStudentSchedule(sessionStorage.client)
      .subscribe(res=>{
        this.nricNumberData=res;
        this.nricNumberList = this.nric_number.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.nric_number)),
          map(name => (name ? this._filterNricNumber(name) : this.nricNumberData.slice())),
        );
      })
  }

  getPassportNumberForStudentSchedule(){
    this.calendarService.getPassportNumberForStudentSchedule(sessionStorage.client)
      .subscribe(res=>{
        this.passportNumberData=res;
        this.passportNumberList = this.passport_number.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.passport_number)),
          map(name => (name ? this._filterPassportNumber(name) : this.passportNumberData.slice())),
        );
      })
  }

  getScheduleList(){
    this.calendarService.getScheduleList()
    .subscribe(res=>{
        this.scheduleList=res['data'];
        for(let i=0;i<this.scheduleList.length;i++){
          this.scheduleList[i].checked=true;
          this.filterItems.push(this.scheduleList[i].status)
        }
    })
  }

  displayFnNRICNUmber(user): string {
    return user && user.nric_number ? user.nric_number : '';
  }

  displayFnPassportNumber(user): string {
    return user && user.passport_number ? user.passport_number : '';
  }


  private _filterNricNumber(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.nricNumberData.filter(option => option.nric_number.toLowerCase().includes(filterValue));
  }

  private _filterPassportNumber(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.passportNumberData.filter(option => option.passport_number.toLowerCase().includes(filterValue));
  }

  calendarOptions: CalendarOptions = {
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek',
    },
    initialView: 'dayGridMonth',
    displayEventTime:false,
    weekends: true,
    editable: true,
    // selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    // select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    eventsSet: this.handleEvents.bind(this),
  };


  changeCategory(event: MatCheckboxChange, filter) {
    if (event.checked) {
      this.filterItems.push(filter.status);
    } else {
      this.filterItems.splice(this.filterItems.indexOf(filter.status), 1);
    }
    this.filterEvent(this.filterItems);
  }

  filterEvent(element) {
    const list = this.calendarEvents.filter((x) =>
      element.map((y) => y).includes(x.title)
    );

    this.calendarOptions.events = list;
  }

  handleEventClick(clickInfo: EventClickArg) {
    this.eventClick(clickInfo);
  }

  eventClick(row) {
   
    const calendarData: any = {
      id: row.event.id,
      title: row.event.title,
      lead_time: row.event._def.extendedProps.lead_time,
      statusid:row.event._def.extendedProps.statusid,
      schedule_name: row.event._def.extendedProps.schedule_name,
      schedule_view:row.event._def.extendedProps.schedule_view,
      schedule_view_assignment:row.event._def.extendedProps.employeeName,
      startDate: row.event.start,
      endDate: row.event.end,
      enrollData:this.enrollDetails
    };

    let tempDirection;
    if (localStorage.getItem('isRtl') === 'true') {
      tempDirection = 'rtl';
    } else {
      tempDirection = 'ltr';
    }

    const dialogRef = this.dialog.open(FormDialogComponent, {
      data: {
        calendar: calendarData,
        action: 'edit',
      },
      direction: tempDirection,
    });

    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 'submit') {
        // this.getScheduleDetails();
        this.addCusForm.reset();
      } else if (result === 'delete') {
        // this.getScheduleDetails();
      }
    });
  }

  editEvent(eventIndex, calendarData) {
    const calendarEvents = this.calendarEvents.slice();
    const singleEvent = Object.assign({}, calendarEvents[eventIndex]);
    singleEvent.id = calendarData.id;
    singleEvent.title = calendarData.title;
    singleEvent.start = calendarData.startDate;
    singleEvent.end = calendarData.endDate;
    singleEvent.className = '';
    singleEvent.groupId = calendarData.category;
    singleEvent.details = calendarData.details;
    calendarEvents[eventIndex] = singleEvent;
    this.calendarEvents = calendarEvents; // reassign the array

    this.calendarOptions.events = calendarEvents;
  }

  handleEvents(events: EventApi[]) {
    // this.currentEvents = events;
  }

  createCalendarForm(calendar): FormGroup {
    return this.fb.group({
      id: [calendar.id],
      lead_time: [
        calendar.lead_time,
        [Validators.required, Validators.pattern('[a-zA-Z]+([a-zA-Z ]+)*')],
      ],
      schedule_name: [calendar.schedule_name],
      schedule_view: [calendar.schedule_view],
      startDate: [calendar.startDate, [Validators.required]],
      endDate: [calendar.endDate, [Validators.required]],
    });
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
    this.snackBar.open(text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }


  selectedNricNumber(event){
    this.enrollDetails=[]; 
    if(event.option.value.id){
      this.passport_number.setValue('');
      this.calendarService.getEnrollmentNumberForSchedule(event.option.value.id,sessionStorage.client)
      .subscribe((res)=>{
          this.enrollDetails=res['enrollData'][0];
          this.calendarData=[];
          for(let i=0;i<res['scheduleList'].length;i++){
            this.calendarData.push({
              title: res['scheduleList'][i].status,
              start: new Date(res['scheduleList'][i].startDate),
              end: new Date(res['scheduleList'][i].endDate),  
              className: res['scheduleList'][i].schedule_color,
              id: res['scheduleList'][i].id,
              statusid:res['scheduleList'][i].status_id,
              schedule_name: res['scheduleList'][i].status,
              schedule_view:res['scheduleList'][i].schedule_view,
              assignment:res['scheduleList'][i].AssignmentList,
              startDate: new Date(res['scheduleList'][i].startDate),
              endDate: new Date(res['scheduleList'][i].endDate),
              employeeName:res['scheduleList'][i].employee_name
            })
          }
          this.calendarEvents=this.calendarData;
          this.tempEvents = this.calendarEvents;
          this.calendarOptions.events = this.calendarEvents;
      })
    }
  }




}
