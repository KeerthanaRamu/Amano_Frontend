import { Component, OnInit,ViewChild,ChangeDetectorRef } from '@angular/core';
import {  FormBuilder, FormGroup, Validators,FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { Observable,map, startWith,debounceTime,switchMap,of } from 'rxjs';
import { StudentService } from '../students.service';
import { LanguageService } from '../../../core/service/language.service';
import {ConfirmDialogComponent} from '../add-student/confirm-dialog/confirm-dialog.component'
import { MatDialog } from '@angular/material/dialog';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { MatStepper } from '@angular/material/stepper';

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null  /* valid option selected */
  }
}

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.sass']
})



export class AddStudentComponent  implements OnInit{

  isLinear = false;
  personalDetailsForm: FormGroup;
  preferenceForm: FormGroup;
  documentForm:FormGroup;
  raceData: any;
  nricTypeData:any;
  nationalityData:any;
  postalCodeData:any;
  existingLicenseData:any;
  preferenceData:any;
  placeBirthData:any;

  race = new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] });
  nricType = new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] }); 
  nationality= new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] });  
  postalCode= new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] });
  existing_license= new FormControl('', { validators: [autocompleteObjectValidator()] });
  preference=new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] });
  placeBirth=new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] });

  raceList: Observable<string[]>;
  nricTypeList: Observable<string[]>;
  nationalityList: Observable<string[]>;
  postalCodeList: Observable<string[]>;
  existingLicenseList: Observable<string[]>;
  preferenceList: Observable<string[]>;
  placeBirthList: Observable<string[]>;
  resultOptions: Observable<any>;


  photo_preview;
  nric_front_preview;
  nric_rear_preview;
  passport_front_preview;
  work_permit_preview;
  existing_license_front_preview;
  existing_license_rear_preview;
  confirmDocumentData;
  confirmPersonalData;
  confirmPreferenceData;

  translateVal=(localStorage.lang == 'ml' ? 'malay' : 'english');
  
  hide = true;
  showOtherRace=false;

  public validation_msgs = {
    'race': [
      { type: 'invalidAutocompleteObject', message: 'Race not recognized. Click one of the options.' },
      { type: 'required', message: 'Race is required.' }
    ],
    'nricType': [
      { type: 'invalidAutocompleteObject', message: 'NRIC Type not recognized. Click one of the options.' },
      { type: 'required', message: 'NRIC Type is required.' }
    ],
    'nationality': [
      { type: 'invalidAutocompleteObject', message: 'Nationality not recognized. Click one of the options.' },
      { type: 'required', message: 'Nationality is required.' }
    ],
    'postalCode': [
      { type: 'invalidAutocompleteObject', message: 'Postal Code not recognized. Click one of the options.' },
      { type: 'required', message: 'Postal Code is required.' }
    ],
    'existing_license': [
      { type: 'invalidAutocompleteObject', message: 'Existing License not recognized. Click one of the options.' }
    ],
    'preference': [
      { type: 'invalidAutocompleteObject', message: 'Prefered Language not recognized. Click one of the options.' },
      { type: 'required', message: 'Prefered Language is required.' }
    ],
    'placeBirth': [
      { type: 'invalidAutocompleteObject', message: 'Place Of Birth not recognized. Click one of the options.' },
      { type: 'required', message: 'Place Of Birth is required.' }
    ]
  }
  

  constructor(private cdRef:ChangeDetectorRef,private fb: FormBuilder,
    private studentService:StudentService,private languageService:LanguageService,public dialog: MatDialog,
    private modalService: NgbModal,private toastrService: ToastrService) {
    this.personalDetailsForm = this.fb.group({
      name: ['',[Validators.required]],
      nric_number: [''],
      passport_number: [''], 
      gender:['', Validators.required],
      ic_address: ['', Validators.required],
      address1: [''],
      address2: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      email_address: ['', [Validators.required, Validators.email, Validators.minLength(5)]],
      mobile_number: ['', Validators.required],
      other_race: [''],
      date_of_birth: ['', Validators.required],
    });
    this.preferenceForm = this.fb.group({
      emergency_name: [''],
      emergency_number: [''],
      user_name: ['', Validators.required],
      password: ['', Validators.required],
      expiry_date:['']
    });
    this.documentForm= new FormGroup({
      photo: new FormControl('',Validators.required),
      photo_name: new FormControl('',Validators.required),
      nric_front: new FormControl(''),
      nric_front_name: new FormControl(''),
      nric_rear: new FormControl(''),
      nric_rear_name: new FormControl(''),
      passport_front: new FormControl(''),
      passport_front_name: new FormControl(''),
      work_permit: new FormControl(''),
      work_permit_name: new FormControl(''),
      existing_license_front: new FormControl(''),
      existing_license_front_name: new FormControl(''),
      existing_license_rear: new FormControl(''),
      existing_license_rear_name: new FormControl(''),
    });
  }

  ngOnInit(): void {
      this.getNRICTypeList();
      this.getRaceList();
      this.getNationalityList();
      this.getExistingLicense();
      this.getPreferenceList();
      this.getPostalCode();
      this.getPlaceBirth();
      this.languageService.languageChanged.subscribe(value => {
        this.translateVal=(localStorage.lang == 'ml' ? 'malay' : 'english');
        this.getNRICTypeList();
        this.getRaceList();
        this.getNationalityList();
        this.getExistingLicense();
        this.getPreferenceList();
        this.getPlaceBirth();
      })

      if(localStorage.PersonalDetails){
        var localPersonalData=JSON.parse(localStorage.PersonalDetails);
        this.personalDetailsForm.patchValue({
          name: localPersonalData.name,
          nric_number: localPersonalData.nric_number,
          passport_number: localPersonalData.passport_number, 
          gender:localPersonalData.gender,
          ic_address:localPersonalData.ic_address,
          address1: localPersonalData.address1,
          address2: localPersonalData.address2,
          city: localPersonalData.city,
          state: localPersonalData.state,
          email_address: localPersonalData.email_address,
          mobile_number: localPersonalData.mobile_number,
          other_race: localPersonalData.other_race,
          date_of_birth: localPersonalData.date_of_birth,
        })
      }

      if(localStorage.race){
       this.race.setValue(JSON.parse(localStorage.race));
      }

      if(localStorage.nricType){
        this.nricType.setValue(JSON.parse(localStorage.nricType));
       }

       if(localStorage.nationality){
        this.nationality.setValue(JSON.parse(localStorage.nationality));
       }

       if(localStorage.placeBirth){
        this.placeBirth.setValue(JSON.parse(localStorage.placeBirth));
       }

       if(localStorage.postalCode){
        this.postalCode.setValue(JSON.parse(localStorage.postalCode));
       }

       if(localStorage.PreferenceDetails){
        this.confirmPreferenceData=JSON.parse(localStorage.PreferenceDetails)
        var localPreferenceData=JSON.parse(localStorage.PreferenceDetails)
        this.preferenceForm.patchValue({
          emergency_name: localPreferenceData.emergency_name,
          emergency_number: localPreferenceData.emergency_number,
          user_name: localPreferenceData.user_name,
          password: localPreferenceData.password,
          expiry_date:localPreferenceData.expiry_date
        })
       }

       if(localStorage.preference){
        this.preference.setValue(JSON.parse(localStorage.preference));
       }
       
       if(localStorage.existing_license){
        this.existing_license.setValue(JSON.parse(localStorage.existing_license));
       }

       if(localStorage.documentDetails){
         var localDocumentData=JSON.parse(localStorage.documentDetails);
         this.documentForm.patchValue({
          photo: localDocumentData.photo,
          photo_name: localDocumentData.photo_name,
          nric_front: localDocumentData.nric_front,
          nric_front_name: localDocumentData.nric_front_name,
          nric_rear: localDocumentData.nric_rear,
          nric_rear_name: localDocumentData.nric_rear_name,
          passport_front: localDocumentData.passport_front,
          passport_front_name: localDocumentData.passport_front_name,
          work_permit: localDocumentData.work_permit,
          work_permit_name: localDocumentData.work_permit_name,
          existing_license_front: localDocumentData.existing_license_front,
          existing_license_front_name: localDocumentData.existing_license_front_name,
          existing_license_rear: localDocumentData.existing_license_rear,
          existing_license_rear_name: localDocumentData.existing_license_rear_name,
         })

         this.photo_preview=localDocumentData.photo;
         this.nric_front_preview=localDocumentData.nric_front;
         this.nric_rear_preview=localDocumentData.nric_rear;
         this.passport_front_preview=localDocumentData.passport_front;
         this.work_permit_preview=localDocumentData.work_permit;
         this.existing_license_front_preview= localDocumentData.existing_license_front;
         this.existing_license_rear_preview= localDocumentData.existing_license_rear;
       }

       console.log("confirmDocumentData===",this.confirmDocumentData)
     
  }

  getRaceList(){   
    this.raceData=[];
    this.studentService.getRaceList()
      .subscribe(res=>{
        this.raceData=res;
        console.log("this.raceData====",this.raceData);
        this.raceList = this.race.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value[this.translateVal])),
          map(name => (name ? this._filterRace(name) : this.raceData.slice())),
        );
      })
  }

  getNRICTypeList(){
    this.nricTypeData=[]
    this.studentService.getNRICTypeList()
      .subscribe(res=>{
        this.nricTypeData=res;
        this.nricTypeList = this.nricType.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value[this.translateVal])),
          map(name => (name ? this._filterNRIC(name) : this.nricTypeData.slice())),
        );
      })
  }

  getPostalCode(){
    this.nricTypeData=[]
    this.studentService.getPostalCode()
      .subscribe(res=>{
        this.postalCodeData=res;
        this.postalCodeList = this.postalCode.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.postal_code)),
          map(name => (name ? this._filterPostalCode(name) : this.postalCodeData.slice())),
        );
      })
  }

  getNationalityList(){
    this.studentService.getNationalityList()
      .subscribe(res=>{
        this.nationalityData=res;
        this.nationalityList = this.nationality.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.country_name)),
          map(name => (name ? this._filterNationality(name) : this.nationalityData.slice())),
        );
      })
  }

  getExistingLicense(){
    this.studentService.getExistingLicense()
      .subscribe(res=>{
        this.existingLicenseData=res;
        this.existingLicenseList = this.existing_license.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value[this.translateVal])),
          map(name => (name ? this._filterExistingLicense(name) : this.existingLicenseData.slice())),
        );
      })
  }

  getPreferenceList(){
    this.studentService.getPreferenceList()
      .subscribe(res=>{
        this.preferenceData=res;
        this.preferenceList = this.preference.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value[this.translateVal])),
          map(name => (name ? this._filterPreference(name) : this.preferenceData.slice())),
        );
      })
  }

  
  getPlaceBirth(){
    this.placeBirthData=[]
    this.studentService.getPlaceBirth()
      .subscribe(res=>{
        this.placeBirthData=res;
        this.placeBirthList = this.placeBirth.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value[this.translateVal])),
          map(name => (name ? this._filterPlaceBirth(name) : this.placeBirthData.slice())),
        );
      })
  }

  displayFn(user): string {
    return user && user[(localStorage.lang == 'ml' ? 'malay' : 'english')] ? user[(localStorage.lang == 'ml' ? 'malay' : 'english')] : '';
  }

  displayFnRace(user): string {
    return user && user[(localStorage.lang == 'ml' ? 'malay' : 'english')] ? user[(localStorage.lang == 'ml' ? 'malay' : 'english')] : '';
  }

  displayFnNationality(user): string {
    return user && user.country_name ? user.country_name : '';
  }

  displayFnPostalCode(user): string {
    return user && user.postal_code ? user.postal_code : '';
  }

  displayFnExistingLicense(user): string {
    return user && user[(localStorage.lang == 'ml' ? 'malay' : 'english')] ? user[(localStorage.lang == 'ml' ? 'malay' : 'english')] : '';
  }

  displayFnPreference(user): string {
    return user && user[(localStorage.lang == 'ml' ? 'malay' : 'english')] ? user[(localStorage.lang == 'ml' ? 'malay' : 'english')] : '';
  }

  displayFnPlaceBirth(user): string {
    return user && user[(localStorage.lang == 'ml' ? 'malay' : 'english')] ? user[(localStorage.lang == 'ml' ? 'malay' : 'english')] : '';
  }

  private _filterRace(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.raceData.filter(option => option[this.translateVal].toLowerCase().includes(filterValue));
  }

  private _filterNRIC(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.nricTypeData.filter(option => option[this.translateVal].toLowerCase().includes(filterValue));
  }

  private _filterNationality(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.nationalityData.filter(option => option.country_name.toLowerCase().includes(filterValue));
  }

  
  private _filterPostalCode(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.postalCodeData.filter(option => option.postal_code.toLowerCase().includes(filterValue));
  }


  private _filterExistingLicense(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.existingLicenseData.filter(option => option[this.translateVal].toLowerCase().includes(filterValue));
  }


  private _filterPreference(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.preferenceData.filter(option => option[this.translateVal].toLowerCase().includes(filterValue));
  }

  
  private _filterPlaceBirth(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.placeBirthData.filter(option => option[this.translateVal].toLowerCase().includes(filterValue));
  }


  onSelectionChange(event){
    console.log('onSelectionChange called', event.option.value);
    if(event.option.value.id === 4){
      this.showOtherRace=true;
    }else{
      this.showOtherRace=false;
    }
  }

  getICTypeChange(){
    console.log("---",this.personalDetailsForm.value.nric_number,this.nricType);
    const restrictList=[1,2,6]
    // this.personalDetailsForm.value.nric_number.charAt(this.personalDetailsForm.value.nric_number.length-1)
    if(restrictList.indexOf(this.nricType.value.id) >= 0){
      if((this.personalDetailsForm.value.nric_number.charAt(this.personalDetailsForm.value.nric_number.length-1)) % 2 == 0){
        this.personalDetailsForm.patchValue({gender:"Female"})
      }else{
        this.personalDetailsForm.patchValue({gender:"Male"})
      }
    }else{
      this.personalDetailsForm.patchValue({gender:""})
    }
  }

  getNRICNumberChange(){
    console.log("---",(this.personalDetailsForm.value.nric_number).substr(2,2));
    this.studentService.checkNRICExistence(this.personalDetailsForm.value.nric_number,sessionStorage.client)
    .subscribe(res=>{
      if(res['status'] == 'New'){
        console.log((this.personalDetailsForm.value.nric_number).substr(2,2)+"/"+(this.personalDetailsForm.value.nric_number).substr(4,2)+"/"+(this.personalDetailsForm.value.nric_number).substr(0,2))
        this.personalDetailsForm.patchValue({date_of_birth:new Date((this.personalDetailsForm.value.nric_number).substr(2,2)+"/"+(this.personalDetailsForm.value.nric_number).substr(4,2)+"/"+(this.personalDetailsForm.value.nric_number).substr(0,2))})
        const restrictList=[1,2,6]
        // this.personalDetailsForm.value.nric_number.charAt(this.personalDetailsForm.value.nric_number.length-1)
        if(restrictList.indexOf(this.nricType.value.id) >= 0){
          if((this.personalDetailsForm.value.nric_number.charAt(this.personalDetailsForm.value.nric_number.length-1)) % 2 == 0){
            this.personalDetailsForm.patchValue({gender:"Female"})
          }else{
            this.personalDetailsForm.patchValue({gender:"Male"})
          }
        }else{
          this.personalDetailsForm.patchValue({gender:""})
        }
      }else{
        this.toastrService.error("NRIC Number Already Exists");
        this.personalDetailsForm.value.nric_number='';
      }
    
    })
   
  }

  getPassportNumberChange(){
    this.studentService.checkPassportExistence(this.personalDetailsForm.value.passport_number,sessionStorage.client)
    .subscribe(res=>{
      if(res['status'] == 'New'){
      }else{
        this.toastrService.error("Passport Number Already Exists");
        this.personalDetailsForm.value.passport_number='';
      }
    })
  }

  getPostalCodeChange(){
    console.log("postalCode===",this.postalCode.value);
    this.personalDetailsForm.patchValue({
      city:this.postalCode.value.city,
      state:this.postalCode.value.state,
    })

  }

  getPersonalDetails(){
    console.log("------personal form--------",this.race);
    localStorage.setItem('PersonalDetails',JSON.stringify(this.personalDetailsForm.value));
    localStorage.setItem('race',JSON.stringify(this.race.value));
    localStorage.setItem('nricType',JSON.stringify(this.nricType.value))
    localStorage.setItem('nationality',JSON.stringify(this.nationality.value))
    localStorage.setItem('postalCode',JSON.stringify(this.postalCode.value))
    localStorage.setItem('placeBirth',JSON.stringify(this.placeBirth.value))
  }

  getPreferenceDetails(stepper: MatStepper){
    console.log("------personal form--------",this.race);
    this.studentService.checkUsernameExistence(this.preferenceForm.value.user_name,sessionStorage.client)
    .subscribe(res=>{
      if(res['status'] == 'New'){
        localStorage.setItem('PreferenceDetails',JSON.stringify(this.preferenceForm.value));
        localStorage.setItem('preference',JSON.stringify(this.preference.value));
        localStorage.setItem('existing_license',JSON.stringify(this.existing_license.value));
        stepper.next();
      }else{
        this.toastrService.error("User Name Already Exists");
        this.preferenceForm.value.user_name='';
      }
    })
  }


  onFileChangePhoto(event,filetype) { 
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      reader.readAsDataURL(file);
      reader.onload = () => {
        console.log("-----",this[filetype+'_preview']);
        this[filetype+'_preview']=reader.result;
        this.documentForm.patchValue({
          [filetype]:reader.result
        })
        console.log("this.documentForm===",this.documentForm)
      }
    }
  }


  saveStudentData(showStudent) {
    localStorage.setItem('documentDetails',JSON.stringify(this.documentForm.value));
    this.confirmPreferenceData=JSON.parse(localStorage.PreferenceDetails);
    this.confirmPersonalData=JSON.parse(localStorage.PersonalDetails);
    this.confirmDocumentData=JSON.parse(localStorage.documentDetails);
    this.modalService.open(showStudent, { ariaLabelledBy: 'modal-basic-title' });
    // const dialogRef = this.dialog.open(ConfirmDialogComponent, {
    //   // data: row,
    //   // direction: tempDirection,
    // });
  }


  setConfirmStudentDetails(){
    this.studentService.setStudentDetails(this.personalDetailsForm.value,this.race.value,this.nricType.value,this.nationality.value,this.postalCode.value,this.existing_license.value,this.preference.value,this.placeBirth.value,this.preferenceForm.value,this.documentForm.value,sessionStorage.currentUser,sessionStorage.client)
    .subscribe(res=>{
      if(res['status'] == 'Success'){
        this.toastrService.success("Registered Successfully!!");
        this.modalService.dismissAll();
        localStorage.removeItem('PersonalDetails');
        localStorage.removeItem('race');
        localStorage.removeItem('nricType');
        localStorage.removeItem('nationality');
        localStorage.removeItem('postalCode');
        localStorage.removeItem('placeBirth');
        localStorage.removeItem('PreferenceDetails');
        localStorage.removeItem('preference');
        localStorage.removeItem('existing_license');
        localStorage.removeItem('documentDetails');
        this.personalDetailsForm.reset();
        this.preferenceForm.reset();
        this.documentForm.reset();
        this.race.setValue('');
        this.nricType.setValue(''); 
        this.nationality.setValue('');  
        this.postalCode.setValue('');
        this.existing_license.setValue('');
        this.preference.setValue('');
        this.placeBirth.setValue('');
        this.photo_preview='';
        this.nric_front_preview='';
        this.nric_rear_preview='';
        this.passport_front_preview='';
        this.work_permit_preview='';
        this.existing_license_front_preview= '';
        this.existing_license_rear_preview='';
      }
        
    })
  }
}
