import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject , ViewChild, ElementRef } from '@angular/core';
import { ScheduleService } from '../../schedule.service';
import {COMMA, ENTER} from '@angular/cdk/keycodes';

import {  FormBuilder, FormGroup, Validators,FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { Observable,map, startWith,debounceTime,switchMap,of } from 'rxjs';

import { Calendar } from '../../schedule.model';
import { formatDate } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import {MatAutocompleteSelectedEvent, MatAutocomplete, MatAutocompleteTrigger} from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null  /* valid option selected */
  }
}

@Component({
  selector: 'app-form-dialog',
  templateUrl: './form-dialog.component.html',
  styleUrls: ['./form-dialog.component.sass']
})


export class FormDialogComponent {

  @ViewChild('autocompleteTrigger') matACTrigger: MatAutocompleteTrigger;
  @ViewChild('licenceInput') licenceInput: ElementRef<HTMLInputElement>;

  action: string;
  dialogTitle: string;
  calendarForm: FormGroup;
  calendar: Calendar;
  showDeleteBtn = false;
  ViewAssignList;
  scheduleList;
  timeArray;

  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  viewAssign_selected= [];

  viewAssignTypeData:any;

  schedule_view_assignment = new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] }); 

  viewAssignTypeList: Observable<string[]>;


  constructor(
    public dialogRef: MatDialogRef<FormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public calendarService: ScheduleService,
    private fb: FormBuilder,private toastrService: ToastrService,
  ) {
    // Set the defaults
    this.getTimeDetails();
    this.action = data.action;
    if (this.action === 'edit') {
     console.log("edit===========",data.calendar)
      this.dialogTitle = data.calendar.title;
      this.calendar = data.calendar;
      this.viewAssign_selected=data.calendar.schedule_view_assignment;
      this.showDeleteBtn = true;
      if(this.calendar.schedule_view != 'All'){
        this.calendarService.getScheduleViewAssignList(this.calendar.schedule_view,sessionStorage.client)
        .subscribe(res=>{
          this.viewAssignTypeData=res['data'];
          console.log("this.viewAssignTypeData===",this.viewAssignTypeData)
          for(let i=0;i<this.viewAssignTypeData.length;i++){
            for(let j=0;j<this.viewAssign_selected.length;j++){
              if(this.viewAssignTypeData[i].id == this.viewAssign_selected[j].id){
                this.viewAssignTypeData[i].checked=true;
              }
            }
          }
          console.log("this.this.schedule_view_assignment=========",this.schedule_view_assignment);
          this.viewAssignTypeList = this.schedule_view_assignment.valueChanges.pipe(
            startWith(''),
            map(value => (typeof value === 'string' ? value : value.name)),
            map(name => (name ? this._filterviewAssignType(name) : this.viewAssignTypeData.slice())),
           );
        })
      }
      this.calendarForm = this.editContactForm();
    } else {
      console.log("newwww--------datad====",data);
      this.dialogTitle = 'New Event';
      this.calendar = new Calendar({});
      this.showDeleteBtn = false;
      this.calendarForm = this.createContactForm(data.calendar);
    }
    
    this.getScheduleList();
  }
  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);
  getErrorMessage() {
    return this.formControl.hasError('required')
      ? 'Required field'
      : this.formControl.hasError('email')
        ? 'Not a valid email'
        : '';
  }
  createContactForm(calendarFm): FormGroup {
    return this.fb.group({
      id: [this.calendar.id],
      lead_time: [
        this.calendar.lead_time,
        [Validators.required]
      ],
      schedule_name: [this.calendar.schedule_name],
      // schedule_owner: [this.calendar.schedule_owner],
      schedule_view: [this.calendar.schedule_view],
      // schedule_view_assignment: [this.calendar.schedule_view_assignment],
      startDate: [calendarFm.start,
      [Validators.required]
      ],
      endDate: [calendarFm.start,
      [Validators.required]
      ]
    });
  }

  editContactForm(): FormGroup {
    return this.fb.group({
      id: [this.calendar.id],
      lead_time: [
        this.calendar.lead_time,
        [Validators.required]
      ],
      schedule_name: [this.calendar.schedule_name],
      // schedule_owner: [this.calendar.schedule_owner],
      schedule_view: [this.calendar.schedule_view],
      startDate: [this.calendar.startDate,
      [Validators.required]
      ],
      endDate: [this.calendar.endDate,
      [Validators.required]
      ]
    });
  }
  submit() {
    // emppty stuff
  }
  deleteEvent() {
    this.calendarService.deleteScheduleDetails(this.calendarForm.value,sessionStorage.currentUser,sessionStorage.client)
    .subscribe(res=>{
      this.toastrService.success("Deleted Successfully!!!!")
      this.dialogRef.close('delete');
    })
    
  }
  onNoClick(): void {
    this.dialogRef.close();
  }


 setScheduleDetails() {
   if(this.action == 'add'){
     if(this.calendarForm.value.schedule_view != "All"){
      console.log("this.viewAssign_selected==",this.viewAssign_selected,this.calendarForm.value);
      if(this.viewAssign_selected.length > 0){
          this.calendarService.setScheduleDetails(this.calendarForm.value,this.viewAssign_selected,sessionStorage.currentUser,sessionStorage.client)
          .subscribe(res=>{
            this.toastrService.success("Updated Successfully!!!!")
            this.dialogRef.close('submit');
          })
      }else{
        this.toastrService.error("Please Select the Schedule View Assignment!!")
      }
     }else{
      console.log("this.viewAssign_selected==",this.viewAssign_selected,this.calendarForm.value);
      this.calendarService.setScheduleDetails(this.calendarForm.value,this.viewAssign_selected,sessionStorage.currentUser,sessionStorage.client)
      .subscribe(res=>{
        this.toastrService.success("Updated Successfully!!!!")
         this.dialogRef.close('submit');
      })
     }
   }
   
   if(this.action == 'edit'){
    if(this.calendarForm.value.schedule_view != "All"){
      console.log("this.viewAssign_selected==",this.viewAssign_selected,this.calendarForm.value);
      if(this.viewAssign_selected.length > 0){
        this.calendarService.updateScheduleDetails(this.calendarForm.value,this.viewAssign_selected,sessionStorage.currentUser,sessionStorage.client)
        .subscribe(res=>{
         this.toastrService.success("Updated Successfully!!!!")
           this.dialogRef.close('submit');
        })
      }else{
        this.toastrService.error("Please Select the Schedule View Assignment!!")
      }
     }else{
      console.log("this.viewAssign_selected==",this.viewAssign_selected,this.calendarForm.value);
      this.calendarService.updateScheduleDetails(this.calendarForm.value,this.viewAssign_selected,sessionStorage.currentUser,sessionStorage.client)
     .subscribe(res=>{
      this.toastrService.success("Updated Successfully!!!!")
        this.dialogRef.close('submit');
     })
     }
     console.log("this.calendarForm.value========",this.calendarForm.value);
   
   }
    
  }


  getScheduleViewAssignList(){
    this.viewAssign_selected=[];
    if(this.calendarForm.value.schedule_view != 'All'){
      this.calendarService.getScheduleViewAssignList(this.calendarForm.value.schedule_view,sessionStorage.client)
      .subscribe(res=>{
          // this.ViewAssignList=res['data'];
          // console.log("this.ViewAssignList====",this.ViewAssignList);
          this.viewAssignTypeData=res['data'];
          console.log("this.this.schedule_view_assignment=========",this.schedule_view_assignment);
          this.viewAssignTypeList = this.schedule_view_assignment.valueChanges.pipe(
            startWith(''),
            map(value => (typeof value === 'string' ? value : value.name)),
            map(name => (name ? this._filterviewAssignType(name) : this.viewAssignTypeData.slice())),
           );
        })
    }
  }

  displayFn(user): string {
    return user && user.name ? user.name : '';
  }

  private _filterviewAssignType(obj): [] {
    console.log("name=====",obj);
    const filterValue = obj.toLowerCase();
    return this.viewAssignTypeData.filter(option => option.name.toLowerCase().includes(filterValue));

  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    console.log("------------",value)
    // Add our fruit
    if ((value || '').trim()) {
      this.viewAssign_selected.push(value);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.schedule_view_assignment.setValue('');
  }

  remove(viewAssign: string): void {
    console.log("viewAssign=========",viewAssign)
    // const index = this.viewAssign_selected.indexOf(viewAssign);
    // console.log("index====",index)
    // if (index >= 0) {
    //   this.viewAssign_selected.splice(index, 1);
    // }   
    if (this.viewAssign_selected.findIndex(item => item.id === viewAssign) >= 0) {
      this.viewAssign_selected = [...this.viewAssign_selected.filter(fruit=>fruit.id !== viewAssign)];
      for(let i=0;i<this.viewAssignTypeData.length;i++){
        if(this.viewAssignTypeData[i].id==viewAssign){
          this.viewAssignTypeData[i].checked=false;
        }
      }
    } 
  }

  openAuto(trigger: MatAutocompleteTrigger) {
    trigger.openPanel();
    this.licenceInput.nativeElement.focus();
    console.log(trigger);
  }

  selectedViewAssignment(event: MatAutocompleteSelectedEvent): void {
    const newValue = event.option.viewValue;
    console.log("newValue=======",event.option);
    console.log(this.viewAssign_selected.findIndex(item => item.id === event.option.value))
    if (this.viewAssign_selected.findIndex(item => item.id === event.option.value) >= 0) {
      this.viewAssign_selected = [...this.viewAssign_selected.filter(fruit=>fruit.name !== newValue)];
      for(let i=0;i<this.viewAssignTypeData.length;i++){
        if(this.viewAssignTypeData[i].id==event.option.value){
          this.viewAssignTypeData[i].checked=false;
        }
      }
    } else {
      for(let i=0;i<this.viewAssignTypeData.length;i++){
        if(this.viewAssignTypeData[i].id==event.option.value){
          this.viewAssignTypeData[i].checked=true;
          this.viewAssign_selected.push(this.viewAssignTypeData[i]);
        }
            
      }
      
    }
    this.licenceInput.nativeElement.value = '';
      this.schedule_view_assignment.setValue('');
    // keep the autocomplete opened after each item is picked.
    requestAnimationFrame(()=>{
      this.openAuto(this.matACTrigger);
    })

  }


  getScheduleList(){
    this.calendarService.getScheduleList()
    .subscribe(res=>{
        this.scheduleList=res['data'];
        console.log("this.ViewAssignList====",this.ViewAssignList)
    })
  }

  getTimeDetails(){
    this.calendarService.getTimeDetails(sessionStorage.client)
    .subscribe((res)=>{
        let resObj=res['data'][0];
        this.makeTimeIntervals((resObj.working_hour_from).substr(0, 5),(resObj.working_hour_to).substr(0, 5),60,(resObj.rest_hour_from).substr(0, 5),(resObj.rest_hour_to).substr(0, 5))
    })
  }


  makeTimeIntervals (startTime, endTime, increment, restStart, restEnd){
    startTime = startTime.toString().split(':');
    endTime = endTime.toString().split(':');
    increment = parseInt(increment, 10);

    var pad = function (n) { return (n < 10) ? '0' + n.toString() : n; },
        startHr = parseInt(startTime[0], 10),
        startMin = parseInt(startTime[1], 10),
        endHr = parseInt(endTime[0], 10),
        endMin = parseInt(endTime[1], 10),
        currentHr = startHr,
        currentMin = startMin,
        previous = currentHr + ':' + pad(currentMin),
        current = '',
        r = [];

    do {
        currentMin += increment;
        if ((currentMin % 60) === 0 || currentMin > 60) {
            currentMin = (currentMin === 60) ? 0 : currentMin - 60;
            currentHr += 1;
        }
        current = currentHr + ':' + pad(currentMin);
        r.push({'range':previous + ' - ' + current,'checked':false});
        previous = current;
  } while (currentHr !== endHr);
      var restTime=restStart+' - '+ restEnd;
      console.log("restStart+ ' - ' + restEnd===",typeof restTime);
      this.timeArray=r.filter((el)=>{return el.range != restTime});
      console.log("this.timeArray====",this.timeArray);
};

}
