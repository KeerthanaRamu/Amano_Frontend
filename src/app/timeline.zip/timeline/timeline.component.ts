import { Component, OnInit,ViewChild,ChangeDetectorRef } from '@angular/core';
import {  FormBuilder, FormGroup, Validators,FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { Observable,map, startWith,debounceTime,switchMap,of } from 'rxjs';
import { LanguageService } from '../core/service/language.service';
import { ToastrService } from 'ngx-toastr';
import {TimelineService} from  './timeline.service'
import {Router,ActivatedRoute} from '@angular/router';

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null  /* valid option selected */
  }
}


@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {

  nricNumberData:any;
  passportNumberData:any;
  tranNumberData:any;
  translateVal;
  statusDone;

  constructor(private cdRef:ChangeDetectorRef,private fb: FormBuilder,
    private languageService:LanguageService,private toastrService: ToastrService,private timelineService:TimelineService,
    private router: Router,private route: ActivatedRoute,) {
     
    }

  nric_number= new FormControl('', { validators: [autocompleteObjectValidator()] });
  passport_number= new FormControl('', { validators: [autocompleteObjectValidator()] });
  registration_no= new FormControl('', { validators: [autocompleteObjectValidator()] });


  nricNumberList: Observable<string[]>;
  passportNumberList: Observable<string[]>;
  tranNumberList: Observable<string[]>;

  statusList:any;

    public validation_msgs = {
      'nric_number': [
        { type: 'invalidAutocompleteObject', message: 'NRIC Number not recognized. Click one of the options.' }
      ],
      'passport_number': [
        { type: 'invalidAutocompleteObject', message: 'Passport Number not recognized. Click one of the options.' }
      ],
      'registration_no': [
        { type: 'invalidAutocompleteObject', message: 'Transaction Number not recognized. Click one of the options.' }
      ]
    }

  ngOnInit(): void {

    this.getNRICNumber();
    this.getPassportNumber();
    this.getStatusList();
    this.languageService.languageChanged.subscribe(value => {
      this.translateVal=(localStorage.lang == 'ml' ? 'malay' : 'english');
    });

  }

  getStatusList(){
    this.timelineService.getStatusList()
    .subscribe(res=>{
      this.statusList=res;
    })
  }

  getNRICNumber(){
    this.timelineService.getAllNRICNumber(sessionStorage.client)
      .subscribe(res=>{
        this.nricNumberData=res;
        this.nricNumberList = this.nric_number.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.nric_number)),
          map(name => (name ? this._filterNricNumber(name) : this.nricNumberData.slice())),
        );
      })
  }

  getPassportNumber(){
    this.timelineService.getAllPassportNumber(sessionStorage.client)
      .subscribe(res=>{
        this.passportNumberData=res;
        this.passportNumberList = this.passport_number.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.passport_number)),
          map(name => (name ? this._filterPassportNumber(name) : this.passportNumberData.slice())),
        );
      })
  }



  selectedNricNumber(event){
    console.log("event.option.value.id===",event.option.value.id);
    if(event.option.value.id){
      this.passport_number.setValue('');
      this.registration_no.setValue('');
      this.tranNumberData=[];
      this.timelineService.getTransactionNumberList(event.option.value.id,sessionStorage.client)
      .subscribe((res)=>{
          console.log("re----nric-----------",res);
          this.tranNumberData=res;
          this.tranNumberList = this.registration_no.valueChanges.pipe(
            startWith(''),
            map(value => (typeof value === 'string' ? value : value.registration_no)),
            map(name => (name ? this._filterTranNumber(name) : this.tranNumberData.slice())),
          );
      })
    }
  }

  selectedPassportNumber(event){
    console.log("event.option.value.id===",event.option.value.id);
    if(event.option.value.id){
      this.nric_number.setValue('');
      this.registration_no.setValue('');
      this.tranNumberData=[];
      this.timelineService.getTransactionNumberList(event.option.value.id,sessionStorage.client)
      .subscribe((res)=>{
        this.tranNumberData=res;
        this.tranNumberList = this.registration_no.valueChanges.pipe(
          startWith(''),
          map(value => (typeof value === 'string' ? value : value.registration_no)),
          map(name => (name ? this._filterTranNumber(name) : this.tranNumberData.slice())),
        );
      })
    }
  }

  checkTimelineForStudent(event){
    console.log("====",this.nric_number.value);
    if(event.option.value.id){
      this.timelineService.checkTimelineForStudent(this.nric_number.value.id,event.option.value.id,sessionStorage.client)
      .subscribe((res)=>{
        console.log("res--===-----",res);
        this.statusDone = res;
        for(let i=0;i<this.statusList.length; i++){
          this.statusList[0]['BColor']='timeline-green';
          this.statusList[0]['scheduled_date']=this.nricNumberData ? this.nricNumberData[0].cur_date : this.passportNumberData[0].cur_date;
          for(let j=0;j<this.statusDone.length;j++){
            if(this.statusList[i].id == this.statusDone[j].status_id){
              this.statusList[i]['BColor']='timeline-green';
              this.statusList[i]['scheduled_date']=this.statusDone[j].scheduled_date;
              this.statusList[i]['completed_date']=this.statusDone[j].completed_date;
            }
          }
        }
        console.log("this.statusList====",this.statusList)
      })
    }
  }

  displayFnNRICNUmber(user): string {
    return user && user.nric_number ? user.nric_number : '';
  }

  displayFnPassportNumber(user): string {
    return user && user.passport_number ? user.passport_number : '';
  }

  displayFnTransactionNumber(user): string {
    console.log("user===",user)
    return user && user.registration_no ? user.registration_no : '';
  }
  
  private _filterNricNumber(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.nricNumberData.filter(option => option.nric_number.toLowerCase().includes(filterValue));
  }

  private _filterPassportNumber(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.passportNumberData.filter(option => option.passport_number.toLowerCase().includes(filterValue));
  }

  private _filterTranNumber(name: string): [] {
    const filterValue = name.toLowerCase();
    return this.tranNumberData.filter(option => option.registration_no.toLowerCase().includes(filterValue));
  }



}
