import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root',
})
export class TimelineService {


  constructor(private http: HttpClient) {
   
  }


  getAllNRICNumber(client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getAllNRICNumber`,{client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getAllPassportNumber(client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getAllPassportNumber`,{client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  getTransactionNumberList(studentdt,client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getTransactionNumberList`,{studentdt,client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  
  getStatusList(){
    return this.http
    .get<any>(`${environment.apiUrl}/webRoutes/getStatusList`)
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

  checkTimelineForStudent(studentid,tranid,client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/checkTimelineForStudent`,{studentid,tranid,client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }

}
