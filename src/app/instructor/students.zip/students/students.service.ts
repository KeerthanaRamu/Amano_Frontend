import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment'

@Injectable({
  providedIn: 'root',
})
export class StudentService {

  constructor(private http: HttpClient) {
   
  }

  getStatusListPerRole(client,authToken){
    return this.http
    .post<any>(`${environment.apiUrl}/instructor/getStatusListPerRole`,{client,authToken})
    .pipe(
      map((res) => {
        // localStorage.setItem('currentUser', JSON.stringify(user));
        // this.currentUserSubject.next(user);
        return res;
      })
    );
  }


  getStudentListPerInstructor(client,authToken){
    return this.http
    .post<any>(`${environment.apiUrl}/instructor/getStudentListPerInstructor`,{client,authToken})
    .pipe(
      map((res) => {
        // localStorage.setItem('currentUser', JSON.stringify(user));
        // this.currentUserSubject.next(user);
        return res;
      })
    );
  }


  getParticularStudentDetails(studentId,client){
    return this.http
    .post<any>(`${environment.apiUrl}/webRoutes/getParticularStudentDetails`,{studentId,client})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }


  updateStudentStatusInfo(studentInfo,status_id,client,authToken){
    return this.http
    .post<any>(`${environment.apiUrl}/instructor/updateStudentStatusInfo`,{studentInfo,status_id,client,authToken})
    .pipe(
      map((res) => {
        return res;
      })
    );
  }


}
