import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { StudentService } from '../students.service';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import {  FormBuilder, FormGroup, Validators,FormControl, AbstractControl, ValidatorFn } from '@angular/forms';


@Component({
  selector: 'app-all-students',
  templateUrl: './all-students.component.html',
  styleUrls: ['./all-students.component.sass'],
})
export class AllStudentsComponent
  implements OnInit
{
  columns = [
    { name: 'Name' },
    { name: 'NRIC Number' },
    { name: 'Passport Number' },
    {name : 'Enrollment Number'},
    {name: 'Gender'},
    {name: 'Mobile'},
    {name: 'Email'},
  ]; 
  data=[];
  filteredData = [];
  translateVal=(localStorage.lang == 'ml' ? 'malay' : 'english');
  statusList;
  updateStatusForm: FormGroup;
  rowTobeUpdated: any;

  constructor(
    public httpClient: HttpClient,
    public dialog: MatDialog,
    public studentsService: StudentService,
    private snackBar: MatSnackBar,private router: Router,
    private modalService: NgbModal,
    private toastrService:ToastrService,
    private fb:FormBuilder
  ) {
    this.updateStatusForm = this.fb.group({
      status_id: ['',[Validators.required]],
    })
  }
  @ViewChild(DatatableComponent, { static: false }) table: DatatableComponent;
  
  ngOnInit() {
    this.loadData();
    this.getStatusListPerRole();
  }
  refresh() {
    this.loadData();
  }

  addNewStudent() {
    this.router.navigate(['/admin/students/add-student'])
  }

  getStatusListPerRole(){
    this.studentsService.getStatusListPerRole(sessionStorage.client,sessionStorage.currentUser)
    .subscribe(res=>{
      this.statusList=res['data'];
      console.log("statusList===",this.statusList);
    })
  }

  public loadData() {
      this.studentsService.getStudentListPerInstructor(sessionStorage.client,sessionStorage.currentUser)
      .subscribe(res=>{
        this.data=res['data'];
        this.filteredData=res['data'];
        
      })
  }


  updateStudentStatusInfo(){
    console.log("status========",this.rowTobeUpdated,this.updateStatusForm.value.status_id)
    this.studentsService.updateStudentStatusInfo(this.rowTobeUpdated,this.updateStatusForm.value.status_id,sessionStorage.client,sessionStorage.currentUser)
    .subscribe(res=>{
      this.toastrService.success("Updated Successfully!!!");
    })
  }

  filterDatatable(event) {
    // get the value of the key pressed and make it lowercase
    const val = event.target.value.toLowerCase();
    // get the amount of columns in the table
    const colsAmt = this.columns.length;
    // get the key names of each column in the dataset
    const keys = Object.keys(this.filteredData[0]);
    // assign filtered matches to the active datatable
    this.data = this.filteredData.filter(function (item) {
      // iterate through each row's column data
      for (let i = 0; i < colsAmt; i++) {
        // check for a match
        if (
          item[keys[i]].toString().toLowerCase().indexOf(val) !== -1 ||
          !val
        ) {
          // found match, return true to add to result set
          return true;
        }
      }
    });
    // whenever the filter changes, always go back to the first page
    this.table.offset = 0;
  }

  editStudent(row, rowIndex,deleteRecord){
    this.modalService.open(deleteRecord, { ariaLabelledBy: 'modal-basic-title' });
    this.rowTobeUpdated=row;
  }



  viewStudent(row, rowIndex){
    this.router.navigate(['/admin/students/about-student',row.id]);
  }
}
